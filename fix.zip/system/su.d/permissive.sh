# !/bin/sh;
echo "0" > /sys/fs/selinux/enforce
setenforce 0
echo "0" > /sys/fs/selinux/enforce
