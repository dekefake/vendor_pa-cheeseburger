# !/bin/sh;
mkdir /supersu
chmod 777 /system/su.d/permissive.sh
mount -o loop /data/su.img /supersu
cp /system/su.d/permissive.sh /supersu/su.d
chmod 777 /system/su.d/permissive.sh
chmod 777 /supersu/su.d/permissive.sh
echo "Permissive setup ran well"
